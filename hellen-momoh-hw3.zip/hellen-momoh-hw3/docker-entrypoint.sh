#!/bin/bash

uvicorn api.service:app --host 0.0.0.0 --port 9000

